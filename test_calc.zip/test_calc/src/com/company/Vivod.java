package com.company;

public class Vivod {

    public void prtText1(String reshenie) {
        System.out.println(reshenie);
    }


}
