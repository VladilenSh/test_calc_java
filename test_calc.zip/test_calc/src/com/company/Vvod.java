package com.company;

import java.util.Scanner;

import static java.lang.System.in;

public class Vvod {
    Scanner in = new Scanner(System.in);

    //public String text1;
    public String getText1() {
      String text1 = in.nextLine();
      return text1;

    }

}
